import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.ensemble import GradientBoostingRegressor
from sklearn.impute import SimpleImputer

# Load your dataset
data = pd.read_csv('Life Expectancy.csv')

# Feature engineering: prepare the features (X) and target (y)
X = data[['Adult Mortality', 'GDP', 'Alcohol', 'Population']]  # Example features
y = data['Life expectancy ']  # Example target

# Handle missing values in X (features) and y (target)
imputer_X = SimpleImputer(strategy='mean')  # Use 'mean' or 'median'
X = imputer_X.fit_transform(X)  # Fit and transform X to handle missing values

imputer_y = SimpleImputer(strategy='mean')  # Impute missing values in y
y = imputer_y.fit_transform(y.values.reshape(-1, 1)).ravel()  # Apply imputer to y and reshape

# Split into training and test datasets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize scaler and encoder
scaler = StandardScaler()
encoder = LabelEncoder()  # Example encoder for categorical features, if needed

# Apply scaling
X_train_scaled = scaler.fit_transform(X_train)  # Fit and transform scaler on training data
X_test_scaled = scaler.transform(X_test)  # Transform test data using the same scaler

# Apply encoder to categorical columns (if any)
# Example: if there are categorical columns in X_train, you would fit the encoder here
# X_train['categorical_feature'] = encoder.fit_transform(X_train['categorical_feature'])
# X_test['categorical_feature'] = encoder.transform(X_test['categorical_feature'])

# Initialize and train the model
model = GradientBoostingRegressor()
model.fit(X_train_scaled, y_train)

# Save the trained model, scaler, and encoder
joblib.dump(model, 'gbm_model.pkl')
joblib.dump(scaler, 'scaler.pkl')
joblib.dump(encoder, 'encoder.pkl')  # Save the encoder (even if it's unused here)

print("Model and preprocessing objects have been saved successfully.")
