from flask import Flask, render_template, request, redirect, url_for, jsonify
import os
import pandas as pd

app = Flask(__name__, template_folder='uploads/templates')

# Set up the folder to store uploaded files
UPLOAD_FOLDER = 'uploads/templates'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['ALLOWED_EXTENSIONS'] = {'html'}

# Ensure the upload folder exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Load the dataset
dataset_path = 'Life Expectancy.csv'
if os.path.exists(dataset_path):
    dataset = pd.read_csv(dataset_path)
    available_features = dataset.columns.tolist()
else:
    dataset = None
    available_features = ['Feature 1', 'Feature 2', 'Feature 3']  # Placeholder features

# Function to check allowed file extensions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

# Route for the homepage, rendering the uploaded index.html dynamically
@app.route('/')
def home():
    index_path = os.path.join(app.config['UPLOAD_FOLDER'], 'index.html')
    if os.path.exists(index_path):
        return render_template('index.html', prediction=None, features=available_features)
    else:
        return "No index.html has been uploaded yet. Please upload a file."

# Route for uploading the HTML file
@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return redirect(request.url)
    file = request.files['file']
    if file.filename == '':
        return redirect(request.url)
    
    if file and allowed_file(file.filename):
        filename = 'index.html'  # Save the uploaded file as index.html
        file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))  # Save the file to the uploads/templates folder
        return redirect(url_for('home'))  # Redirect back to the homepage after upload

# Route for predictions via form submission
@app.route('/predict', methods=['POST'])
def predict():
    feature_name = request.form.get('feature')
    if feature_name not in available_features:
        return f"Invalid feature name. Available features: {', '.join(available_features)}"
    
    # Generate a dummy prediction for the selected feature
    try:
        if dataset is not None and feature_name in dataset.columns:
            if feature_name in dataset.select_dtypes(include='number').columns:
                dummy_prediction = round(dataset[feature_name].mean(), 2)  # Mean as a dummy prediction
            else:
                dummy_prediction = "N/A"  # Non-numeric columns
        else:
            dummy_prediction = "Feature not found"
        
        return render_template(
            'index.html', 
            prediction=f"Prediction for {feature_name}: {dummy_prediction}", 
            features=available_features
        )
    except Exception as e:
        return str(e)

if __name__ == '__main__':
    app.run(debug=True)
