from flask import Flask, request, render_template_string, jsonify

app = Flask(__name__)

@app.route('/')
def upload_page():
    return '''
    <!doctype html>
    <title>Upload HTML File</title>
    <h1>Upload Your HTML File</h1>
    <form action="/upload" method="post" enctype="multipart/form-data">
      <input type="file" name="file">
      <input type="submit" value="Upload">
    </form>
    '''

@app.route('/upload', methods=['POST'])
def upload_file():
    uploaded_file = request.files['file']
    if uploaded_file and uploaded_file.filename.endswith('.html'):
        html_content = uploaded_file.read().decode('utf-8')
        return render_template_string(html_content)
    else:
        return "Please upload a valid HTML file.", 400

@app.route('/predict', methods=['POST'])
def predict():
    data = request.json
    return jsonify({'prediction': "Example prediction result"})

if __name__ == '__main__':
    app.run(debug=True)
